namespace DemoShop.Web.Configuration
{
    public class CardPaymentsConfiguration
    {
        public string CentralApiCardPaymentsUrl { get; set; }
    }
}