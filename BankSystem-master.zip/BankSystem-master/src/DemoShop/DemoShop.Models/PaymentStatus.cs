namespace DemoShop.Models
{
    public enum PaymentStatus
    {
        Pending,
        Completed
    }
}