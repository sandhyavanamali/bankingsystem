﻿namespace CentralApi.Services.Models.Banks
{
    public class BankServiceModel : BankBaseServiceModel
    {
        public string ApiAddress { get; set; }

        public string ApiKey { get; set; }
    }
}