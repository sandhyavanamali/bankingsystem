﻿namespace CentralApi.Services.Models.Banks
{
    using BankSystem.Common.AutoMapping.Interfaces;
    using CentralApi.Models;

    public class BankBaseServiceModel : IMapWith<Bank>
    {
    }
}