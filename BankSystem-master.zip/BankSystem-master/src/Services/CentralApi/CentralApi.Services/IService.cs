﻿namespace CentralApi.Services
{
    // Marker interface
    public interface IService
    {
    }
}