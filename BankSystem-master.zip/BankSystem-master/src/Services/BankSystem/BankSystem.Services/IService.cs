﻿namespace BankSystem.Services
{
    // Marker interface
    public interface IService
    {
    }
}