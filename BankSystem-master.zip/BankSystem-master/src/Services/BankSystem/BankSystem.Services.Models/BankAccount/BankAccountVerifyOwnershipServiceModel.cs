﻿namespace BankSystem.Services.Models.BankAccount
{
    public class BankAccountVerifyOwnershipServiceModel : BankAccountBaseServiceModel
    {
        public string UserId { get; set; }
    }
}