﻿namespace CentralApi.Models
{
    public class CardPaymentReceiveModel
    {
        public string PaymentInfo { get; set; }
    }
}